types =[45,1.2,True,"sri","5"]
for i in types:
    print("{} is of the data type {}".format(i,type(i)))