myString="this is a string"
print(myString)
print(type(myString))
first="waater"
second="fall"
third=first+second
print(third)
name=input("what is your name :")
print(name)
color=input("what is your favourite color : ")
animal=input("what is your fav animal ")
print("{},you like a {} {}".format(name,color,animal))