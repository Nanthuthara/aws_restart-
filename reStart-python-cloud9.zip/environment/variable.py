myValue=1
print(myValue)
print(type(myValue))
print(str(myValue)+" is the type of"+str(type(myValue)))
myValue=1.5
print(myValue)
print(type(myValue))
print(str(myValue)+" is the type of"+str(type(myValue)))
myValue=5j
print(myValue)
print(type(myValue))
print(str(myValue)+" is the type of"+str(type(myValue)))
myValue=True
print(myValue)
print(type(myValue))
print(str(myValue)+" is the type of"+str(type(myValue)))