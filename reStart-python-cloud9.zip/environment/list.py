fruit=["apple","banana","cherry"]
print(fruit)
print(type(fruit))
print(fruit[0])
fruit[0]="orange"
print(fruit)
#tuple
fruit=("apple","banana","cherry")
print(fruit)
print(type(fruit))
print(fruit[0])
dictionary={
    "name":"sri",
    "age" : 15
}
print(dictionary)
print(type(dictionary))
print(dictionary["name"])